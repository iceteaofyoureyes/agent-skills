# Composition và ownership

**Trạng thái: DRAFT — WAITING_FOR_HUMAN_APPROVAL**

## Thành phần tối thiểu

1. **Project-owned workflow/router:** chọn stage hợp lệ, pin input/revision, gọi capability, dừng tại Human Gate, ghi provenance. Stage là trạng thái workflow, không phải skill.
2. **Exact upstream TEA:** giữ nguyên behavior test analysis/design ở pinned commit; dùng BA → TEA adapter chỉ để đáp ứng input shape.
3. **Project-owned deterministic adapters và canonical model/validator:** chuyển format, giữ ID/UNKNOWN/provenance, kiểm tra trace và chống semantic drift; không làm test reasoning.
4. **Exact upstream Katalon:** giữ nguyên behavior tạo detailed manual testcases ở pinned commit; workflow chỉ cấp approved design và BA oracle, không yêu cầu TestOps writes.
5. **Human Gate policy:** chỉ quyết định Human explicit mới cho qua hai điểm review.
6. **Optional renderers (PROPOSED):** XMind và Excel là projection từ canonical snapshot khi Human yêu cầu; không tham gia semantic gates.

Thứ tự lựa chọn là `EXACT_UPSTREAM → THIN ADAPTER → MINIMAL PATCH → PROJECT_OWNED only when necessary`. Benchmark không chứng minh failure cần patch upstream. Workflow/adapter/config đủ cho phần project-owned; không tạo skill test-analysis, test-design, testcase-generation hoặc traceability mới.

## Ownership matrix

| Responsibility | Owner / provenance | Input | Output | Lý do |
|---|---|---|---|---|
| Workflow routing | Test Kit workflow / project-owned | User intent, state, source refs, gate receipts | Stage hợp lệ hoặc STOP | Chỉ điều phối; upstream vẫn sở hữu methodology. |
| Source authority | Test Kit authority policy / project-owned; Human sở hữu business decisions | BA baseline, approved design, supplemental system evidence | Nguồn được phép dùng và conflict/UNKNOWN | Tránh code/template ghi đè BA. |
| Test Design generation | TEA / exact upstream | BA → TEA input, pinned config | Raw Test Design | Benchmark chấp nhận TEA qua structural adapter. |
| Test Design normalization | Deterministic adapter / project-owned | Raw TEA design | Canonical Test Design + provenance + metadata riêng | Giữ semantic và ID, loại planning metadata khỏi BA truth. |
| Human Test Design approval | Human; workflow chỉ ghi receipt | Canonical design revision + review context | APPROVE hoặc REQUEST_CHANGES | Agent không có quyền tự duyệt. |
| Testcase generation | Katalon / exact upstream | Approved design snapshot + BA oracle | Raw manual cases | Benchmark chấp nhận semantic reasoning; không cần TestOps. |
| Testcase normalization | Deterministic adapter / project-owned | Raw Katalon cases | Canonical Testcases + provenance | Chuẩn hóa trường và ref mà không thêm expected behavior. |
| Human testcase approval | Human; workflow chỉ ghi receipt | Canonical testcase revision + review context | APPROVE hoặc REQUEST_CHANGES | Giữ quyền final testware ở Human. |
| Traceability | Canonical fields + validator / project-owned | FR/BR, TD, TC refs | `Requirement → Test Design → Testcase` map và lỗi cụ thể | Là invariant dữ liệu; không cần skill riêng. |
| UNKNOWN propagation | Adapters + validator / project-owned; Human/BA giải quyết nghiệp vụ | BA open items, raw design/cases | UNKNOWN refs, blocked assertions, review questions | Không biến chỗ trống thành expected result. |
| XMind export | Optional renderer / project-owned, **PROPOSED** | Canonical design snapshot + explicit Human request | XMind projection | Chỉ định dạng trình bày; không là nguồn chân lý. |
| Excel export | Optional renderer / project-owned, **PROPOSED** | Canonical testcase snapshot + explicit Human request | Excel projection | Chỉ định dạng trình bày; không là workflow gate. |

## Lifecycle và stop conditions

`DRAFT_DESIGN → DESIGN_REVIEW → APPROVED_DESIGN → DRAFT_CASES → CASE_REVIEW → APPROVED_TESTWARE → STOP_V1`. `REQUEST_CHANGES` quay về đúng draft stage; sửa BA semantics thì quay về BA authority trước khi tạo lại derived artifacts. Không đi tiếp khi input/gate revision stale, nguồn thiếu, ref không khớp, hoặc conflict chưa được Human xử lý.

Renderer tùy chọn có thể nhận một canonical snapshot sau khi nó tồn tại và có explicit Human request; kết quả render không làm thay đổi state hoặc approval của snapshot. Không có trigger tự động khi bấm `Continue`.
