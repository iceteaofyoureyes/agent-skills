# Semantic, adapter và Human Gate contracts

**Trạng thái: DRAFT — WAITING_FOR_HUMAN_APPROVAL**

## 1. Source authority

```text
Approved BA baseline (Business Rules + SRS; handoff chỉ định nguồn/revision)
  > Approved Test Design (truth cho testcase generation, trong phạm vi BA)
  > supplemental CURRENT_SYSTEM evidence
  > TEA/Katalon planning suggestions (non-authoritative)
```

BA baseline quyết định expected **business** behavior. Test Design đã được Human duyệt quyết định scenario/coverage phải chuyển thành testcase nhưng không được override BA. Current code chỉ mô tả hệ thống hiện tại; TEA risk score, P0–P3, coverage target, effort, test level và Katalon suggestions chỉ là planning metadata. Handoff ví dụ có tham chiếu `02-gap-review.md`; tham chiếu đó không nâng supporting/history thành authority cao hơn approved BR/SRS. `01-input-requirement.md` cũng chỉ là history.

Khi hai nguồn mâu thuẫn hoặc một behavior thiếu authority: ghi `CONFLICT` hoặc `UNKNOWN` kèm source refs, dừng assertion và đưa Human/BA quyết định; không chọn theo code, upstream, adapter hoặc số đông. Bốn oracle CR-001 luôn để `UNKNOWN`: maximum Appointment duration; list filters; default sorting; pagination/page size. Có thể có case cho quy tắc đã biết (duration > 0, xem Appointment), nhưng không có pass/fail cho giá trị còn UNKNOWN.

## 2. BA → TEA input adapter

**Input:** đúng BA BR/SRS revision và handoff path/hash, source ID, open items; current-system context có nhãn supplemental riêng. **Output:** TEA-compatible structure/config và source map từ mỗi đoạn chuyển sang path + ID gốc. Với CR-001, benchmark đã dùng epic-level wrapper cho sáu FR vì system-level input đòi architecture/ADR không có trong baseline.

Adapter chỉ được đổi cấu trúc, heading và path; có thể chép nguyên văn FR/BR và stable ID. Không sinh actor, rule, acceptance criterion, UI/API contract, scenario hoặc giá trị UNKNOWN mới. Config chọn workflow mode/output path/language; không sửa TEA methodology. Nếu không map nguyên vẹn hoặc nguồn có conflict, fail và nêu vị trí; không tự viết lại nội dung để TEA chạy được.

## 3. TEA → Canonical Test Design

**Input:** raw TEA design + pinned upstream revision + source map. **Output:** canonical design revision gồm ít nhất:

| Field | Contract |
|---|---|
| `design_id`, `parent_id`/`hierarchy_path` | ID ổn định và cây nhóm/scenario; không tạo duplicate semantic node. |
| `scenario`, `expected_behavior` | Ý định và outcome quan sát được, giữ nguyên semantics từ raw output. |
| `requirement_refs` | FR/BR IDs có nguồn; rỗng hoặc không resolve được là review finding. |
| `priority` | Tùy chọn; ghi rõ `planning_advisory`, không là BA truth hay release gate. |
| `open_items` | UNKNOWN/CONFLICT ID, mô tả và BA source ref; không ép thành expected result. |
| `provenance` | Raw path/section, input revision/hash, TEA commit, adapter version, normalization map. |

TEA risk/effort/coverage target/test level/ownership/generic gates nằm trong `planning_metadata` tách khỏi canonical semantic fields và khỏi Katalon oracle. Nếu raw scenario không thể phân biệt expected behavior với suggestion, adapter phải flag Human review, không đoán. Normalized matrix của benchmark là trace/oracle fixture, chưa phải schema/runtime canonical hoàn chỉnh.

## 4. Canonical Test Design → Katalon input

**Precondition:** Human `APPROVE` receipt khớp chính xác canonical design revision/hash và BA baseline còn hiệu lực. **Output:** Katalon-consumable text/structure gồm scenario hierarchy, intent, expected behavior, FR/BR/TD refs, open items, và BA sources để đối chiếu oracle. Adapter chỉ đổi format/field names/path; không thêm testcase intent hoặc business rule.

Prompt/invocation ràng buộc Katalon tạo manual cases từ **approved** design, cho phép tách một TD thành các case độc lập hoặc gộp compatible journey khi không mất assertion/trace (benchmark: TD-001 + TD-014 → TC-001); không redesign approved semantics. New insight/coverage suggestion được ghi riêng cho Human review, không âm thầm thêm vào approved design. Không gọi Katalon project lookup, TestOps create/update/link, suite hoặc execution cho V1 semantic workflow.

## 5. Katalon → Canonical Testcase

**Input:** raw Katalon semantic output + approved design snapshot. **Output:** mỗi manual testcase có ít nhất:

| Field | Contract |
|---|---|
| `testcase_id`, `name`, `objective` | ID ổn định và đúng một validation intent. |
| `preconditions`, `steps`, `test_data` | Case có thể setup độc lập; step dùng business/UI terms; data tách khỏi action khi phù hợp. |
| `expected_result` | Quan sát được, cụ thể, có thể truy về approved design/BA. |
| `priority` | Planning label, có nguồn; không tự thành business requirement. |
| `requirement_refs`, `test_design_refs` | FR/BR và TD IDs; nếu ref không recover được, ghi unresolved để review, không bịa ID. |
| `review_status` | Ban đầu `DRAFT`; `APPROVED` chỉ là trạng thái suy ra từ Human gate receipt khớp revision/hash. |
| `provenance`, `open_items` | Raw location, upstream/input revisions và UNKNOWN/execution dependencies. |

Adapter map field names, giữ thứ tự steps và expected result; không tự chia/gộp case hay viết thêm assertions. Validator flag case thiếu precondition/data, case quá mỏng, duplicate intent, outcome không được source/design hỗ trợ, và gaps trong TD coverage. Những flag này là review findings, không là quyền Agent approve. TC-012 cần approved editable-field contract; các interval case cần fixture/interface contract xác định khoảng hiển thị. Giữ placeholder/dependency đến khi authority cung cấp dữ liệu, không tự chọn field hay công thức end time.

## 6. Human Gate và traceability

Hai gate riêng: `DESIGN_REVIEW` sau canonical design, `CASE_REVIEW` sau canonical cases. Decision hợp lệ chỉ `APPROVE` hoặc `REQUEST_CHANGES`, do Human đưa rõ gate + artifact ID/revision/hash; workflow ghi actor, thời điểm, quyết định, feedback và input refs. `Continue`, `Next`, “Looks okay-ish”, validation `PASS`, raw output, benchmark fixture permission và lời Agent đều không là approval. Agent không ghi hoặc suy diễn `APPROVED`.

`REQUEST_CHANGES` tạo revision mới qua đúng upstream stage; receipt cũ không duyệt revision mới. Nếu BA baseline hoặc approved design thay đổi, downstream approval liên quan trở thành stale và phải review lại. `APPROVE` Test Design chỉ cho phép Stage 3; `APPROVE` testcases mới tạo Approved Testware. Approval của proposal tài liệu này cũng không tự approve bất kỳ artifact chạy thử nào.

Trace invariant: mỗi canonical TD có ít nhất một FR/BR ref hợp lệ; mỗi canonical TC có ít nhất một TD ref và đi được đến FR/BR qua TD. Ref trực tiếp trên TC phải khớp hoặc là subset phù hợp của nguồn TD/BA; mọi TD trong approved design phải có testcase coverage hoặc explicit Human disposition. Validator báo cạnh thiếu, ref lạ, orphan, UNKNOWN bị biến thành assertion và semantic drift kèm source → TD → TC evidence. Validator không sinh trace mới và không thay Human Gate.

## 7. Optional projection interfaces — PROPOSED

`render_xmind(canonical_design_snapshot, HUMAN_EXPLICIT_REQUEST) → XMind artifact + source revision` và `render_excel(canonical_testcases_snapshot, HUMAN_EXPLICIT_REQUEST) → Excel artifact + source revision`. Renderer đọc snapshot, giữ ID/trace/UNKNOWN, không mutate source hay approval; render failure chỉ thuộc projection lane. XMind/Excel không là gate và không là source of truth.

**PROPOSED, chưa final:** thiếu renderer không làm semantic Test Kit `DEGRADED` nếu workflow/gates/trace vẫn hoàn chỉnh. Điều này cần Human quyết định vì [BA Kit contract](../../vi/KIT_CONTRACT.md) hiện quy định thiếu capability optional tạo `DEGRADED`; proposal chưa sửa contract đó.
