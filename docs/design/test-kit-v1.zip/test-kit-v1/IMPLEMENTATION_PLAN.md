# Quyết định mở và thứ tự triển khai đề xuất

**Trạng thái: DRAFT — WAITING_FOR_HUMAN_APPROVAL**

## Quyết định Human còn mở

1. Phê duyệt hoặc yêu cầu sửa composition, canonical fields, gate receipt/invalidation và ownership trong proposal này. Chưa có component V1 nào được chấp thuận để implement.
2. Quyết định riêng đề xuất projection status: thiếu XMind/Excel renderer có làm `DEGRADED` hay không, đồng thời hòa giải với `docs/vi/KIT_CONTRACT.md`. Hiện vẫn **PROPOSED**.
3. Khi đưa CR-001 vào testware thực thi: BA/UX/interface authority cần cung cấp editable-field contract cho TC-012 và các case edit tương tự; interval fixture/end mapping và UI labels cần contract phù hợp. Không gán default, max duration, list filters, sorting hoặc page size trong proposal.
4. Chọn nơi lưu gate receipts/canonical revisions và cơ chế pin/hash trong runtime hiện có sau khi khảo sát integration thực tế; tài liệu này chỉ định invariant, không đặt schema/file layout hay thêm service mới.

## Implementation order sau approval của proposal

1. **Runtime proof cho từng upstream:** `install/register → discovery → invocation → output` ở đúng pinned revision; ghi version/provenance và xác nhận capability thực sự được gọi. Benchmark trước chỉ chạy tuần tự từ pinned skill content, nên bước này là gap integration chưa được kiểm chứng. Nếu runtime chỉ hỗ trợ cách đó, ghi rõ limitation và đưa Human chọn trước khi tuyên bố integration-ready.
2. Dùng workflow/router mỏng và BA → TEA structural adapter để tạo raw design; định nghĩa canonical design/normalizer và validator trace/UNKNOWN. So sánh với benchmark fixture nhưng không sửa benchmark.
3. Gắn `DESIGN_REVIEW` Human Gate với exact snapshot; chỉ sau `APPROVE` mới cấp input cho Katalon.
4. Dùng approved design → Katalon adapter, normalize manual cases, kiểm tra source/design coverage và unknown; gắn `CASE_REVIEW` Human Gate. Sau Human `APPROVE`, đóng ở `APPROVED_TESTWARE`/`STOP_V1`.
5. Chỉ nếu Human quyết định cần, định nghĩa renderer XMind/Excel riêng và trigger `HUMAN_EXPLICIT_REQUEST`. Renderer không chặn đường semantic.

Không implement trong proposal này: Test Kit code/skill mới, upstream patch, Katalon TestOps writes, automation, execution, release gate, XMind/Excel renderer, hay sửa Petclinic/BA baseline/benchmark evidence. Nếu tương lai xuất hiện failure có evidence, đề xuất minimal patch map đúng failure trước khi sửa upstream; hiện hai benchmark không có patch candidate.
