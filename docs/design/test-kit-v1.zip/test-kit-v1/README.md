# Test Kit V1 — proposal

**Trạng thái: DRAFT — WAITING_FOR_HUMAN_APPROVAL**

Test Kit V1 ghép hai capability upstream đã benchmark với một workflow project-owned mỏng. Phạm vi semantic dừng ở **Approved Testware** (Test Design và manual testcases đã được Human duyệt); không sinh automation hoặc chạy test. Proposal này chưa phải quyết định triển khai hay approval cho bất kỳ Test Design/testcase sản phẩm nào.

```text
Approved BA Baseline
  → TEA Test Design → Canonical Test Design → Human APPROVE
  → Katalon Create Test Cases → Canonical Testcases → Human APPROVE
  → Approved Testware → STOP V1
```

- [Composition và ownership](COMPOSITION.md)
- [Source authority, adapter, model, gate và traceability contracts](CONTRACTS.md)
- [Quyết định còn mở và thứ tự triển khai](IMPLEMENTATION_PLAN.md)

## Evidence cố định cho proposal

| Stage | Upstream capability | Pinned commit | Benchmark verdict | Evidence |
|---|---|---|---|---|
| 1–2 | `bmad-code-org/bmad-method-test-architecture-enterprise` / `bmad-testarch-test-design` | `1f53e9095061ab66f3c35abd9b98baf0f50cf8fe` | `ACCEPT_WITH_THIN_ADAPTER` | [TEA benchmark](../../../benchmark/test-kit/petclinic/tea-test-design/README.md) |
| 3 | `katalon-labs/true-skills` / `skills/create-test-cases` | `e6cdd774f66ce9d45ea5904101a96203e3a37581` | `ACCEPT_WITH_THIN_ADAPTER` | [Katalon benchmark](../../../benchmark/test-kit/petclinic/katalon-create-test-cases/README.md) |

BA truth của ví dụ CR-001: [Business Rules](../../../kits/ba/examples/CR-001/vi/03-approved-business-rules.md), [SRS](../../../kits/ba/examples/CR-001/vi/04-srs-excerpt.md), [engineering handoff](../../../kits/ba/examples/CR-001/vi/05-engineering-handoff.yml). Benchmark dùng `agent-skills` SHA `cb2b834b45d5a9aadebf5627d7bb966401b1c5f5`; Petclinic Angular `1978a75eab0c803595d5cde75acc6a0a9bcff4de`, REST `4cd8e1b0cd42578e882247d8801f6be5d402f118`.

Benchmark Stage 3 được Human cho dùng Test Design còn nhãn Draft làm **fixture riêng của benchmark**. Quyền đó không thay thế gate phê duyệt Test Design trong V1. Hai benchmark chạy tuần tự từ pinned skill content vì capability chưa được runtime đăng ký; khả năng install/discovery/invocation thực tế còn phải chứng minh.
